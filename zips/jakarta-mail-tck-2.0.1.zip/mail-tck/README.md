# Jakarta Mail TCK

This is the standalone Jakarta Mail TCK.  Running this TCK requires a mail
server with an account that the TCK can use.

* TCK User's Guide - [pdf](docs/Jakarta-Mail-TCK-Users-Guide.pdf), [html](docs/html/toc.html)
* [Javadocs for test classes](docs/javadocs/index.html)
